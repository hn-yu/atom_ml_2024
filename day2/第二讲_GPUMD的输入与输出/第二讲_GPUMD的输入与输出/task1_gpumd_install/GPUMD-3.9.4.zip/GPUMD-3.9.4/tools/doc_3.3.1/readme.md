The PDF contains documentation specific for GPUMD-v3.3.1 and older versions, which contain some empirical potentials that are absent in the newer versions. 
