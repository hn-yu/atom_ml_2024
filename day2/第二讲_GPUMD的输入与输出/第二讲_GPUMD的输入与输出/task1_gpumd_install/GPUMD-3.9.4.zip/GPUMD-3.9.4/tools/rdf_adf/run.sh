#!/bin/bash
set -e
set -u

# First you need to download ovitos: https://www.ovito.org/linux-downloads/
#   and assign the path to its home directory to OVITO-PTAH.
# ${OVITO-PTAH}/bin/ovitos rdf_adf_ovito.py

# You can then use Python to output the PDF.
# python plot_rdf_adf.py
