# Dump_pol every iteration
# 550k atoms
# 20 iterations

Baseline (no dump_pol), 51.3
Atomicadd, 68.9
Reduce1, 70.4
Reduce2, 69.4
Reduce3, 68.9
Reduce4, 70.9
No write: 69
No reduce & no write: 69
No force: 50
 
