.. _credits:
.. index:: Credits

.. |br| raw:: html

  <br/>


Credits
*******

TBC


Acknowledgments
---------------
* `NSFC <http://www.nsfc.gov.cn/>`_ with project numbers 11404033 and 11974059
* `Aalto Science-IT project <http://science-it.aalto.fi/>`_
* `Finland's IT Center for Science (CSC) <https://www.csc.fi/>`_
