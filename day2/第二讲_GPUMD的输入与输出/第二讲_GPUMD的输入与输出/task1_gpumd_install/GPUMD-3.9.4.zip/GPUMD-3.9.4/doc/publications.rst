.. _publications:
.. index:: Publications

Publications
************
   
2024
====
.. bibliography::
   :list: enumerated
   :filter: year % "2024"

2023
====
.. bibliography::
   :list: enumerated
   :filter: year % "2023"

2022
====
.. bibliography::
   :list: enumerated
   :filter: year % "2022"

2021
====
.. bibliography::
   :list: enumerated
   :filter: year % "2021"

2020
====
.. bibliography::
   :list: enumerated
   :filter: year % "2020"

2019
====
.. bibliography::
   :list: enumerated
   :filter: year % "2019"

2018
====
.. bibliography::
   :list: enumerated
   :filter: year % "2018"

2017
====
.. bibliography::
   :list: enumerated
   :filter: year % "2017"

2016
====
.. bibliography::
   :list: enumerated
   :filter: year % "2016"

2015
====
.. bibliography::
   :list: enumerated
   :filter: year % "2015"

2013
====
.. bibliography::
   :list: enumerated
   :filter: year % "2013"
