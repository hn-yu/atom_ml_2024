.. _theory:
.. index::
   single: Theoretical background

Theoretical background
**********************

.. toctree::
   :maxdepth: 2
   :caption: Contents

   forces_and_stresses
   ensembles
   heat_current
   heat_transport
