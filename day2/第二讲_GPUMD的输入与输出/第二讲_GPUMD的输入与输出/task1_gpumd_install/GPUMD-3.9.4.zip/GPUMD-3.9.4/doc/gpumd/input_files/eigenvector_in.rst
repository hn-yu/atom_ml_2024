.. _eigenvector_in:
.. index::
   single: gpumd input files; Eigenvectors
   single: eigenvector.in

Eigenvectors for modal analysis
-------------------------------
